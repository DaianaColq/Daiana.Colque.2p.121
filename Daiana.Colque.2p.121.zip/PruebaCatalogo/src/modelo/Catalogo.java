package modelo;

import java.io.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;

public class Catalogo<T extends CSVSerializable & Comparable<T>> implements Serializable {

    private List<T> elementos = new ArrayList<>();

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public T obtenerPorIndice(int indice) {
        return elementos.get(indice);
    }

    public void eliminarPorIndice(int indice) {
        elementos.remove(indice);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        return elementos.stream()
                .filter(criterio)
                .collect(Collectors.toList());
    }

    public void ordenar() {
        Collections.sort(elementos);
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    public void paraCadaElemento(Consumer<T> accion) {
        elementos.forEach(accion);
    }

    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ruta))) {
            out.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) in.readObject();
        }
    }

    public void guardarEnCSV(String ruta) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                writer.println(elemento.toCSV());
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws IOException {
        elementos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                elementos.add(fromCSV.apply(linea));
            }
        }
    }
}