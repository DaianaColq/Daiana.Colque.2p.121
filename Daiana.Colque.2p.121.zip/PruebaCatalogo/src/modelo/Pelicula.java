package modelo;

import java.io.Serializable;

public class Pelicula implements CSVSerializable, Comparable<Pelicula>, Serializable {

    private final int id;
    private final String titulo;
    private final String director;
    private final Genero genero;

    public Pelicula(int id, String titulo, String director, Genero genero) {
        this.id = id;
        this.titulo = titulo;
        this.director = director;
        this.genero = genero;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDirector() {
        return director;
    }

    public Genero getGenero() {
        return genero;
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + director + "," + genero;
    }

    public static Pelicula fromCSV(String csv) {
        String[] partes = csv.split(",");
        int id = Integer.parseInt(partes[0]);
        String titulo = partes[1];
        String director = partes[2];
        Genero genero = Genero.valueOf(partes[3]);
        return new Pelicula(id, titulo, director, genero);
    }

    @Override
    public int compareTo(Pelicula otra) {
        return Integer.compare(this.id, otra.id);
    }

    @Override
    public String toString() {
        return id + " - " + titulo + " (" + genero + "), dirigido por " + director;
    }
}