package app;

import config.Rutas;
import modelo.*;

import java.io.IOException;
import java.util.Comparator;
import modelo.Catalogo;

public class Main {

    public static void main(String[] args) {

        try {
            // Crear un catálogo de películas
            Catalogo<Pelicula> catalogoPeliculas = new Catalogo<>();

            catalogoPeliculas.agregar(new Pelicula(1, "El Padrino", "Francis Ford Coppola", Genero.DRAMA));
            catalogoPeliculas.agregar(new Pelicula(2, "La La Land", "Damien Chazelle", Genero.COMEDIA));
            catalogoPeliculas.agregar(new Pelicula(3, "Guerra Mundial Z", "Marc Forster", Genero.TERROR));
            catalogoPeliculas.agregar(new Pelicula(4, "Toy Story", "John Lasseter", Genero.ANIMACION));
            catalogoPeliculas.agregar(new Pelicula(5, "The Social Dilemma", "Jeff Orlowski", Genero.DOCUMENTAL));
            
            // Mostrar todas las películas en el catálogo
            System.out.println("Catalogo de peliculas:");
            catalogoPeliculas.paraCadaElemento(System.out::println);
            
            // Filtrar películas por género COMEDIA
            System.out.println("\nPeliculas de genero COMEDIA:");
            catalogoPeliculas.filtrar(p -> p.getGenero() == Genero.COMEDIA)
                             .forEach(System.out::println);
            
            // Filtrar películas cuyo título contiene "Guerra"
            System.out.println("\nPeliculas cuyo titulo contiene 'Guerra':");
            catalogoPeliculas.filtrar(p -> p.getTitulo().toLowerCase().contains("guerra"))
                             .forEach(System.out::println);
            
            // Ordenar películas de manera natural (por id)
            System.out.println("\nPeliculas ordenadas de manera natural (por id):");
            catalogoPeliculas.ordenar();
            catalogoPeliculas.paraCadaElemento(System.out::println);
            
            // Ordenar películas por título usando Comparator
            System.out.println("\nPeliculas ordenadas por titulo:");
            catalogoPeliculas.ordenar(Comparator.comparing(Pelicula::getTitulo));
            catalogoPeliculas.paraCadaElemento(System.out::println);

            // Guardar el catálogo en archivo binario
            catalogoPeliculas.guardarEnArchivo(Rutas.ARCHIVO_BINARIO);

            // Cargar el catálogo desde archivo binario
            Catalogo<Pelicula> catalogoCargado = new Catalogo<>();
            catalogoCargado.cargarDesdeArchivo(Rutas.ARCHIVO_BINARIO);
            System.out.println("\nPeliculas cargadas desde archivo binario:");
            catalogoCargado.paraCadaElemento(System.out::println);
            
            // Guardar el catálogo en archivo CSV
            catalogoPeliculas.guardarEnCSV(Rutas.ARCHIVO_CSV);
            
            // Cargar el catálogo desde archivo CSV
            catalogoCargado.cargarDesdeCSV(Rutas.ARCHIVO_CSV, Pelicula::fromCSV);
            System.out.println("\nPeliculas cargadas desde archivo CSV:");
            catalogoCargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}