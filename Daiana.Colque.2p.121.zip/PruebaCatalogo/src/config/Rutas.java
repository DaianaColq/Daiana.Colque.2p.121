package config;

public class Rutas {
    public static final String ARCHIVO_BINARIO = "src/data/peliculas.dat";
    public static final String ARCHIVO_CSV = "src/data/peliculas.csv";
}